//
//  AppDelegate.h
//  ae-PaySlip
//
//  Created by Harish Kn on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

