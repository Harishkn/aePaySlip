//
//  DashBoardViewController.h
//  ae-PaySlip
//
//  Created by Harish Kn on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "BaseViewController.h"

@interface DashBoardViewController : BaseViewController
@property (strong, nonatomic) IBOutlet UIImageView *profileImage;

@property (strong, nonatomic) IBOutlet UIButton *paySlipBtnOutlet;
@property (strong, nonatomic) IBOutlet UIButton *p60BtnOutLet;
@property (strong, nonatomic) IBOutlet UIButton *p11DBtnOutLet;
@property (strong, nonatomic) IBOutlet UIButton *p6p9BtnOutLet;

@property (strong, nonatomic) IBOutlet UIButton *pensionBtnOutLet;
@property (strong, nonatomic) IBOutlet UIButton *rotaBtnOutLet;
- (IBAction)uploadImage:(id)sender;

@end
