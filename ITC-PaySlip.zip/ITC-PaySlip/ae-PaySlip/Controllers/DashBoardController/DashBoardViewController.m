//
//  DashBoardViewController.m
//  ae-PaySlip
//
//  Created by Harish Kn on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "DashBoardViewController.h"
#import "CameraAccess.h"
#import "EmployeePaySlipVC.h"
#import "RotaReportVC.h"

@class CameraAccess;


@interface DashBoardViewController () <CameraDelegate>

@property (strong, nonatomic) IBOutlet UIBarButtonItem *refresh;
@property (strong,nonatomic)CameraAccess* camera;

@end

@implementation DashBoardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //set your image frame
    UIImageView *image=[[UIImageView alloc]initWithFrame:CGRectMake(0,0,70,40)] ;
    
    //set your image logo replace to the main-logo
    [image setImage:[UIImage imageNamed:@"logoae"]];
    
  image.contentMode = UIViewContentModeScaleAspectFit;
    
    [self.navigationController.navigationBar.topItem setTitleView:image];
    
    
    
    
    self.pensionBtnOutLet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.p60BtnOutLet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.p11DBtnOutLet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.p6p9BtnOutLet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.paySlipBtnOutlet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.rotaBtnOutLet.layer.borderColor = [[UIColor lightGrayColor]CGColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)uploadImage:(id)sender {
    
    self.camera = [[CameraAccess alloc] init];
    self.camera.delegate = self;
    [self.camera takeOrChoosePhoto:(BaseViewController *)self];

}

-(void)selectedImage:(UIImage *)img
{
    self.profileImage.image = img;
}
- (IBAction)paySlip:(id)sender {
    
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"EmployeePayslip" bundle:nil];
    EmployeePaySlipVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"EmployeePaySlip"];

   [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)p60Btn:(id)sender {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"EmployeePayslip" bundle:nil];
    EmployeePaySlipVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"EmployeePaySlip"];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)p11DBtn:(id)sender {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"EmployeePayslip" bundle:nil];
    EmployeePaySlipVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"EmployeePaySlip"];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)p6p9Btn:(id)sender {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"EmployeePayslip" bundle:nil];
    EmployeePaySlipVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"EmployeePaySlip"];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)pensionBtn:(id)sender {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"EmployeePayslip" bundle:nil];
    EmployeePaySlipVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"EmployeePaySlip"];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)rotaBtn:(id)sender {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"RotaReport" bundle:nil];
    RotaReportVC* vc = [storyBoard instantiateViewControllerWithIdentifier:@"RotaReport"];
    
    [self.navigationController pushViewController:vc animated:YES];
}
@end
