//
//  PasscodeViewController.h
//  ae-PaySlip
//
//  Created by Raghavendra Dattawad on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PasscodeViewController : UIViewController

@end
