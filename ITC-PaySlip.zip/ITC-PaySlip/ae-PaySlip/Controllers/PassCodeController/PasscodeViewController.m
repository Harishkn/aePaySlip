//
//  PasscodeViewController.m
//  ae-PaySlip
//
//  Created by Raghavendra Dattawad on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "PasscodeViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface PasscodeViewController ()<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *passcode;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *passcodeImg;
@property (strong, nonatomic) IBOutlet UILabel *displayInfoLabel;

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

@end

@implementation PasscodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self.passcode addTarget:self
                      action:@selector(textFieldDidChange:)
            forControlEvents:UIControlEventEditingChanged];
    

    for (UIImageView *img in self.passcodeImg) {
        

        CALayer *borderLayer = [CALayer layer];
        CGRect borderFrame = CGRectMake(0, 0, (img.frame.size.width), (img.frame.size.height));
       [borderLayer setFrame:borderFrame];
        img.layer.borderWidth = 1.0f;
        [borderLayer setBorderColor:[[UIColor blackColor] CGColor]];
        [img.layer addSublayer:borderLayer];
    }
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.displayInfoLabel.text=[NSString stringWithFormat:@"Hi Robert Redford \n Please enter your 4-digit Passcode to Sign In."];
    
}

-(void)textFieldDidChange:(UITextField *)textfiled;{
    
    NSLog(@"%@",textfiled.text);
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    const char *changeCharecter=[string  cStringUsingEncoding:NSUTF8StringEncoding];
     int isBackSpace = strcmp(changeCharecter, "\b");
    
    if (range.location <4) {
        
          if (isBackSpace==-8) {
            
            [[self.passcodeImg objectAtIndex:range.location]setImage:[UIImage imageNamed:@""]];
            return YES;
            
          }
          else {
            
            [[self.passcodeImg objectAtIndex:range.location]setImage:[UIImage imageNamed:@"star"]];
            return YES;
            
            
             }
    }
    
    
    return NO;
}

- (IBAction)tapGesture:(id)sender {

    [self.passcode becomeFirstResponder];


}
#pragma mark - UITextField delegate methods
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
}
- (void)keyboardWillShow:(NSNotification *)note {
    // create custom button
    UIButton *forgotPasscodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    forgotPasscodeBtn.frame = CGRectMake(0, 163, 106, 53);
    forgotPasscodeBtn.adjustsImageWhenHighlighted = NO;
    //    [doneButton setImage:[UIImage imageNamed:@"doneButtonNormal.png"] forState:UIControlStateNormal];
    //    [doneButton setImage:[UIImage imageNamed:@"doneButtonPressed.png"] forState:UIControlStateHighlighted];
    
   // forgotPasscodeBtn.titleLabel.font = [UIFont fontWithName:@"Arial-MT" size:5];
    //[forgotPasscodeBtn setValue:[UIFont fontWithName:@"Arial-MT" size:10] forKey:UIControlStateNorma];
    forgotPasscodeBtn.titleLabel.font = [UIFont systemFontOfSize: 14];
    forgotPasscodeBtn.titleLabel.numberOfLines=2;
   
    [forgotPasscodeBtn setTitle:@"Forgot\nPasscode?" forState:UIControlStateNormal];
    [forgotPasscodeBtn addTarget:self action:@selector(forgotButton:) forControlEvents:UIControlEventTouchUpInside];
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIView *keyboardView = [[[[[UIApplication sharedApplication] windows] lastObject] subviews] firstObject];
            
            [forgotPasscodeBtn setFrame:CGRectMake(0, keyboardView.frame.size.height - 53, 106, 53)];
            
            [keyboardView addSubview:forgotPasscodeBtn];
            [keyboardView bringSubviewToFront:forgotPasscodeBtn];
            
            [UIView animateWithDuration:[[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue]-.02
                                  delay:.0
                                options:[[note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] intValue]
                             animations:^{
                                 self.view.frame = CGRectOffset(self.view.frame, 0, 0);
                                 
                             } completion:nil];
        });
    }else {
        // locate keyboard view
        dispatch_async(dispatch_get_main_queue(), ^{
            UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
            //UIView* keyboard;
            for(int i=0; i<[tempWindow.subviews count]; i++) {
                UIView *keyboard = [tempWindow.subviews objectAtIndex:i];
                // keyboard view found; add the custom button to it
                if([[keyboard description] hasPrefix:@"UIKeyboard"] == YES)
                    [keyboard addSubview:forgotPasscodeBtn];
            }
        });
    }
}
-(IBAction)forgotButton:(id)sender{
    
    [self performSegueWithIdentifier:@"forgotPasscode" sender:self];
    
}

@end
