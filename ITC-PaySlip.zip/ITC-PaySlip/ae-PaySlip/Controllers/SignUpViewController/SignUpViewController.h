//
//  SignUpViewController.h
//  ae-PaySlip
//
//  Created by ableindia on 27/02/1939 Saka.
//  Copyright © 1939 Saka ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *displayHeaderLabel;

@end
