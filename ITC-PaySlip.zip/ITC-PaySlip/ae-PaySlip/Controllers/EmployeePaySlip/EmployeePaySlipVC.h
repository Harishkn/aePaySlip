//
//  EmployeePaySlipVC.h
//  ae-PaySlip
//
//  Created by Mahaboobsab Nadaf on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeePaySlipVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UIDocumentInteractionControllerDelegate>
@property(strong,nonatomic)NSArray *monthsName;
@property (strong, nonatomic) IBOutlet UITableView *employeeTableView;
@property(strong,nonatomic)NSArray *monthsNumber;
@end
