//
//  EmployeePaySlipVC.m
//  ae-PaySlip
//
//  Created by Mahaboobsab Nadaf on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "EmployeePaySlipVC.h"
#import "EmployeePaySlipTableViewCell.h"
@interface EmployeePaySlipVC (){
    
    
    UIDocumentInteractionController *docController;
    
    
}


@end

@implementation EmployeePaySlipVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.employeeTableView.delegate = self;
    
    [self.employeeTableView setSeparatorColor:[UIColor redColor]];
    self.employeeTableView.layoutMargins = UIEdgeInsetsZero;
    self.employeeTableView.separatorInset = UIEdgeInsetsZero;
    
    
    self.monthsNumber = [[NSArray alloc] initWithObjects:@"Month 10",@"Month 9",@"Month 8",@"Month 7",@"Month 6",@"Month 8", nil];// TODO: Meheboob : API Pending
    self.monthsName = [[NSArray alloc] initWithObjects:@"February 2017",@"January 2017",@"December 2016",@"November 2016",@"October 2016",@"December 2016", nil];// TODO: Meheboob : API Pending
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.monthsNumber.count;// TODO: Meheboob : API Pending
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    EmployeePaySlipTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    //cell.layoutMargins = UIEdgeInsetsZero;
    
    [cell updateCellViews:[self.monthsNumber objectAtIndex:indexPath.row] :[self.monthsName objectAtIndex:indexPath.row]];
        return cell;// TODO: Meheboob : API Pending
}
- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    
   
        return @"Select Payslip Period";
  
    
    
}


//
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 45;
}
//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    UIView *headerVw = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 30)] ;
//    //headerVw.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"title_bg.png"]]; // set color of header
//    
//    UILabel *itemlbl = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 320, 20)];
//    
//    
//        itemlbl.text = @"Select Payslip Period";
//  
//    
//    itemlbl.textAlignment = UITextAlignmentCenter;
//    itemlbl.backgroundColor = [UIColor clearColor];
//    itemlbl.textColor = [UIColor redColor];
//    itemlbl.font = [UIFont boldSystemFontOfSize:14];
//    [headerVw addSubview:itemlbl];
//   
//    return headerVw;
//}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [self openPdf:nil];
    NSLog(@"%ld",(long)indexPath.row);
}// TODO: Meheboob : API Pending

- (void)openPdf : (NSData*)pdf
{
    
    NSURL *URL = [[NSBundle mainBundle] URLForResource:@"Auto_Enrolment" withExtension:@"PDF"];
    UIDocumentInteractionController *documentInteractionController =[UIDocumentInteractionController interactionControllerWithURL:URL];
    documentInteractionController.delegate = self;
    [documentInteractionController presentPreviewAnimated:YES];
    
    
    
    
    // Generate PDF Data.
//    NSData *pdfData = pdf;
//    
//    // Create a filePath for the pdf.
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"Report.pdf"];
//    
//    // Save the PDF. UIDocumentInteractionController has to use a physical PDF, not just the data.
//    [pdfData writeToFile:filePath atomically:YES];
//    
//    // Open the controller.
//    docController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:filePath]];
//    docController.delegate = self;
//    docController.UTI = @"com.adobe.pdf";
//    //[docController presentOpenInMenuFromBarButtonItem:button animated:YES];
//    
//    [ docController presentPreviewAnimated:YES];
    
}// TODO: Meheboob : API Pending

- (UIViewController *) documentInteractionControllerViewControllerForPreview: (UIDocumentInteractionController *) controller {
    return self;
}
@end
