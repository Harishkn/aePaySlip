//
//  EmployeePaySlipTableViewCell.m
//  ae-PaySlip
//
//  Created by Mahaboobsab Nadaf on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "EmployeePaySlipTableViewCell.h"

@implementation EmployeePaySlipTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)updateCellViews:(NSString *)monthNumber : (NSString *)monthName{


    self.monthNumber.text = monthNumber;
    self.monthName.text = monthName;

}
@end
