//
//  EmployeePaySlipTableViewCell.h
//  ae-PaySlip
//
//  Created by Mahaboobsab Nadaf on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeePaySlipTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *monthNumber;
@property (strong, nonatomic) IBOutlet UILabel *monthName;
-(void)updateCellViews:(NSString *)monthNumber : (NSString *)monthName;
@end
