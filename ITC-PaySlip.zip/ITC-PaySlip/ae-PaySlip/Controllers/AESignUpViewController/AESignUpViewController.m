//
//  AESignUpViewController.m
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "AESignUpViewController.h"

@interface AESignUpViewController ()

@end

@implementation AESignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.titleArray = [[NSArray alloc]initWithObjects:@"Personal Name *",@"Date of Birth *",@"Mobile No *",@"Create Passcode *",@"Confirm Passcode *", nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    AEalertController *controller = [[AEalertController alloc] init];
    controller.delegate = self;
    
    [controller showAlertMessageInViewController:self title:@"Terms of Service and Privacy Policy" message:@"I Agree to accept the Terms of Service and Privacy Policy of aeExchange Limited" okTitle:@"OK" cancelTitle:@"Don't Allow"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - aeBaseAlert Delegate methods -

-(void)ok
{
    
}

-(void)cancel
{
    
}

#pragma mark - TableView delegate methods -

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [self.titleArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *cellIdentifier = @"signUp";
    SignUpTableViewCell *svc = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    svc.title.text = [NSString stringWithFormat:@"%@",[self.titleArray objectAtIndex:indexPath.row]];
    return svc;
}







/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
