//
//  SignUpTableViewCell.m
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "SignUpTableViewCell.h"
#import "UITextField+CustomTextField.h"

@implementation SignUpTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    [self.content bottomBorderForTextField];
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
