//
//  SignUpTableViewCell.h
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UITextField *content;

@end
