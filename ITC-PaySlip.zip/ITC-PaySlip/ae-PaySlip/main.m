//
//  main.m
//  ae-PaySlip
//
//  Created by Harish Kn on 15/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
