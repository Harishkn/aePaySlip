//
//  AEalertController.h
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol aeBaseAlert <NSObject>

-(void)ok;
-(void)cancel;

@end

@interface AEalertController : UIAlertController

@property (weak, nonatomic) id<aeBaseAlert> delegate;


-(void)showAlertMessageInViewController:(UIViewController *)viewController title:(NSString *)title message:(NSString *)message okTitle:(NSString *)ok cancelTitle:(NSString *)cancel;
@end
