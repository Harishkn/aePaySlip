//
//  AEalertController.m
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "AEalertController.h"

@interface AEalertController ()

@end

@implementation AEalertController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)showAlertMessageInViewController:(UIViewController *)viewController title:(NSString *)title message:(NSString *)message okTitle:(NSString *)ok cancelTitle:(NSString *)cancel
{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okBtn = [UIAlertAction actionWithTitle:ok style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // [self.delegate OkAction];
    }];
    
    UIAlertAction *canelBtn = [UIAlertAction actionWithTitle:cancel style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // [self.delegate cancelAction];
    }];
    
    
    [controller addAction:canelBtn];
    [controller addAction:okBtn];
    
    [viewController presentViewController:controller animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
