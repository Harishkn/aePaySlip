//
//  CameraAccess.h
//  PassItOnApp
//
//  Created by bhaskar ns on 02/05/17.
//  Copyright © 2017 bhaskar ns. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseViewController.h"


@protocol CameraDelegate <NSObject>

-(void)selectedImage :(UIImage *)img;

@end

@interface CameraAccess : BaseViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>


-(IBAction)takeOrChoosePhoto:(BaseViewController *)vc;

@property (weak, nonatomic) id<CameraDelegate> delegate;

@end
