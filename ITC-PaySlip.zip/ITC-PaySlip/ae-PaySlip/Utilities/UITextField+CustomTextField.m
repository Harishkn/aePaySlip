//
//  UITextField+CustomTextField.m
//  ae-PaySlip
//
//  Created by bhaskar ns on 16/05/17.
//  Copyright © 2017 ITCS. All rights reserved.
//

#import "UITextField+CustomTextField.h"

@implementation UITextField (CustomTextField)



-(void)bottomBorderForTextField{


    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 0.5f;
    border.borderColor = [UIColor blueColor].CGColor;
    border.frame = CGRectMake(0, self.frame.size.height - borderWidth, self.frame.size.width, self.frame.size.height);
    border.borderWidth = borderWidth;
    [self.layer addSublayer:border];
    self.layer.masksToBounds = YES;
    
}

@end
